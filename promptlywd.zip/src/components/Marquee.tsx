import { motion } from "framer-motion";

const items = ["WEB DESIGN", "BRAND IDENTITY", "DEVELOPMENT", "STRATEGY", "MOTION", "SEO"];

export const Marquee = () => {
  return (
    <div className="relative overflow-hidden border-y border-border py-6 bg-secondary/40">
      <motion.div
        className="flex gap-16 whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      >
        {[...items, ...items, ...items, ...items].map((item, i) => (
          <span key={i} className="font-serif text-4xl md:text-6xl italic text-muted-foreground flex items-center gap-16">
            {item}
            <span className="text-primary not-italic">✦</span>
          </span>
        ))}
      </motion.div>
    </div>
  );
};
