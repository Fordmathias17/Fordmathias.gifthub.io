import { motion } from "framer-motion";
import { Layers, Sparkles, Zap, LineChart } from "lucide-react";

const services = [
  { icon: Layers, title: "Custom Web Design", desc: "Bespoke marketing sites and landing pages tailored to your brand and audience." },
  { icon: Sparkles, title: "Brand-Led Visuals", desc: "Distinctive aesthetics, type systems, and motion that make you unforgettable." },
  { icon: Zap, title: "Fast Development", desc: "Modern stack, lightning-fast load times, optimized for every device." },
  { icon: LineChart, title: "Conversion Strategy", desc: "Designed around the user journey so every section earns its place." },
];

export const Services = () => {
  return (
    <section id="services" className="relative px-6 md:px-12 py-32 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-20 flex-wrap gap-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground mb-4">
              ◆ What I do
            </p>
            <h2 className="font-serif text-5xl md:text-7xl leading-none">
              Web design,<br />
              <span className="italic text-gradient">end to end.</span>
            </h2>
          </div>
          <p className="max-w-sm text-muted-foreground">
            One designer, one developer, one point of contact. No agency overhead — just sharp, considered work.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-px bg-border rounded-3xl overflow-hidden">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="group relative bg-card p-10 md:p-12 hover:bg-secondary transition-colors duration-500"
            >
              <s.icon className="w-8 h-8 text-primary mb-8 group-hover:scale-110 group-hover:rotate-3 transition-transform duration-500" />
              <h3 className="font-serif text-3xl md:text-4xl mb-4">{s.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{s.desc}</p>
              <span className="absolute top-10 right-10 font-mono text-xs text-muted-foreground">0{i + 1}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
