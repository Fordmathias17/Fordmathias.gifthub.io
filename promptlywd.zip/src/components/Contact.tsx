import { motion } from "framer-motion";
import { Mail, Phone, ArrowUpRight } from "lucide-react";
import logo from "@/assets/promptly-logo.png";

export const Contact = () => {
  return (
    <section id="contact" className="relative px-6 md:px-12 py-32 bg-background overflow-hidden grain">
      <div className="absolute inset-0 bg-hero opacity-60" />
      <div className="relative max-w-6xl mx-auto">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground mb-8">
          ◆ Let's build something
        </p>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="font-serif text-[clamp(3rem,10vw,9rem)] leading-[0.9] tracking-tight mb-16"
        >
          Got a project? <br />
          <span className="italic text-gradient">Let's talk.</span>
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-6">
          <a
            href="mailto:fordmathias17@yahoo.com"
            className="group p-8 md:p-10 rounded-3xl bg-card border border-border hover:border-primary hover:shadow-glow transition-all duration-500"
          >
            <Mail className="w-7 h-7 text-primary mb-6" />
            <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-3">Email</p>
            <div className="flex items-center justify-between gap-4">
              <span className="font-serif text-xl sm:text-2xl md:text-3xl whitespace-nowrap">fordmathias17@yahoo.com</span>
              <ArrowUpRight className="w-6 h-6 shrink-0 group-hover:rotate-45 group-hover:text-primary transition-all duration-500" />
            </div>
          </a>

          <a
            href="tel:+12542141343"
            className="group p-8 md:p-10 rounded-3xl bg-card border border-border hover:border-primary hover:shadow-glow transition-all duration-500"
          >
            <Phone className="w-7 h-7 text-primary mb-6" />
            <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-3">Call / Text</p>
            <div className="flex items-center justify-between gap-4">
              <span className="font-serif text-2xl md:text-3xl">(254) 214-1343</span>
              <ArrowUpRight className="w-6 h-6 shrink-0 group-hover:rotate-45 group-hover:text-primary transition-all duration-500" />
            </div>
          </a>
        </div>

        <footer className="mt-32 pt-10 border-t border-border flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <img src={logo} alt="Promptly" width={24} height={24} loading="lazy" className="w-6 h-6" />
            <span className="font-serif italic text-xl">promptly</span>
            <span className="font-mono text-xs text-muted-foreground ml-3">© {new Date().getFullYear()} Mathias Ford</span>
          </div>
          <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
            Available for new projects
          </p>
        </footer>
      </div>
    </section>
  );
};
