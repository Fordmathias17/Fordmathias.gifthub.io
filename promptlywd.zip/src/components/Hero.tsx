import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import heroMesh from "@/assets/hero-mesh.jpg";

export const Hero = () => {
  return (
    <section id="top" className="relative min-h-screen flex flex-col justify-end px-6 md:px-12 pt-32 pb-12 overflow-hidden grain bg-hero">
      <img
        src={heroMesh}
        alt=""
        width={1920}
        height={1280}
        className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-screen"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

      <div className="relative max-w-7xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center gap-3 mb-8 font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground"
        >
          <span className="w-8 h-px bg-primary" />
          Independent web design studio · est. 2024
        </motion.div>

        <h1 className="font-serif text-[clamp(3.5rem,12vw,12rem)] leading-[0.85] tracking-tight">
          {["We", "design", "websites", "that"].map((word, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 80 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.1 * i, ease: [0.22, 1, 0.36, 1] }}
              className="inline-block mr-[0.2em]"
            >
              {word}
            </motion.span>
          ))}
          <motion.span
            initial={{ opacity: 0, y: 80 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="inline-block italic text-gradient"
          >
            convert.
          </motion.span>
        </h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="mt-12 flex flex-col md:flex-row md:items-end md:justify-between gap-8"
        >
          <p className="max-w-md text-lg text-muted-foreground leading-relaxed">
            Promptly is a one-person web design studio crafting fast, beautiful, conversion-obsessed websites for ambitious companies.
          </p>
          <a
            href="#contact"
            className="group inline-flex items-center gap-3 self-start md:self-auto px-7 py-4 rounded-full border border-foreground/20 hover:border-primary hover:bg-primary hover:text-primary-foreground transition-all duration-500"
          >
            <span className="font-mono text-sm uppercase tracking-wider">Book a call</span>
            <ArrowUpRight className="w-4 h-4 group-hover:rotate-45 transition-transform duration-500" />
          </a>
        </motion.div>
      </div>
    </section>
  );
};
