import { motion } from "framer-motion";

export const About = () => {
  return (
    <section id="about" className="relative px-6 md:px-12 py-32 bg-secondary/30 overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground mb-8">
          ◆ About
        </p>
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="font-serif text-4xl md:text-6xl leading-[1.05] tracking-tight"
        >
          Hi, I'm <span className="italic text-gradient pr-2 inline-block">Mathias Ford</span> — the designer, developer, and project lead behind Promptly. I partner with founders and marketing teams to build websites that look elite and actually move the needle.
        </motion.h2>

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-border">
          {[
            { k: "50+", v: "Sites shipped" },
            { k: "100%", v: "Custom designed" },
            { k: "<2s", v: "Avg load time" },
            { k: "1:1", v: "Direct contact" },
          ].map((stat) => (
            <div key={stat.v}>
              <div className="font-serif text-4xl md:text-5xl text-gradient">{stat.k}</div>
              <div className="font-mono text-xs uppercase tracking-wider text-muted-foreground mt-2">{stat.v}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
