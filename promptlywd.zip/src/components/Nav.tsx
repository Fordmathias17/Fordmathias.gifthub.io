import { motion } from "framer-motion";
import logo from "@/assets/promptly-logo.png";

export const Nav = () => {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-5 backdrop-blur-xl bg-background/40 border-b border-border/50"
    >
      <nav className="flex items-center justify-between max-w-7xl mx-auto">
        <a href="#top" className="flex items-center gap-2.5 group">
          <img src={logo} alt="Promptly" width={32} height={32} className="w-8 h-8 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500 drop-shadow-[0_0_12px_hsl(var(--primary)/0.5)]" />
          <span className="font-serif italic text-2xl tracking-tight">promptly</span>
        </a>
        <div className="hidden md:flex items-center gap-10 text-sm font-mono uppercase tracking-wider">
          <a href="#work" className="hover:text-primary transition-colors">Work</a>
          <a href="#services" className="hover:text-primary transition-colors">Services</a>
          <a href="#about" className="hover:text-primary transition-colors">About</a>
        </div>
        <div />

      </nav>
    </motion.header>
  );
};
