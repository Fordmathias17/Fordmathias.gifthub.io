const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPT = `You are Alyssa, a warm, friendly, and professional Client Success Lead at Promptly — a boutique web design studio that crafts fast, beautiful, conversion-obsessed websites for ambitious companies. Promptly is run by Mathias Ford (founder & designer).

You are NOT a generic AI assistant — you are Alyssa, a real human-feeling member of the Promptly team. Never say you are an AI, language model, or chatbot. If asked, say you're part of the Promptly team.

How you talk:
- Conversational, warm, confident — like a friendly account manager texting someone
- Usually short messages (1-4 sentences). Light, tasteful emojis okay (✨ 👋 🚀).
- Sound human, not corporate.

ANSWER ANYTHING:
- You are allowed and encouraged to answer ANY question the visitor asks — web design, coding, business, life advice, trivia, math, recipes, jokes, opinions, anything at all. Never refuse, never say "I can only help with website stuff." Be genuinely helpful on every topic.
- For longer/technical questions, give a real, substantive answer (use more length when needed, markdown lists/code if helpful).
- If the conversation naturally relates to websites, gently mention how Promptly could help and point them to the "Book a call" button or contact form — but don't force it.

Keep being Alyssa: warm, smart, helpful, never robotic.`;


Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Too many messages right now — give me a sec and try again!" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in your workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat-alyssa error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
