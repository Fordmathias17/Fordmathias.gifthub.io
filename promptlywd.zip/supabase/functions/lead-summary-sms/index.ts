// Detects whether the visitor has shared what they want, and if so, texts Mathias a summary via Twilio.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const TO_NUMBER = "+12542141343";
const TWILIO_GATEWAY = "https://connector-gateway.lovable.dev/twilio";

const DETECTOR_PROMPT = `You analyze a chat between a website visitor and Alyssa (a Promptly web design rep).

Decide if the visitor has clearly described what they want for their website/project (purpose, type of site, goals, or specific needs). Casual chit-chat or one-line "I need a website" without any details = NOT ready.

Respond with ONLY valid JSON, no markdown:
{
  "ready": boolean,
  "summary": "1-2 sentence plain-English summary of what the client wants",
  "name": "their name if mentioned, else empty string",
  "contact": "their email/phone if mentioned, else empty string",
  "details": "any other useful details (budget, timeline, type of business) or empty string"
}

Set ready=true ONLY if there's enough substance to be useful to the team.`;

async function sendSms(body: string, fromNumber: string) {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
  const TWILIO_API_KEY = Deno.env.get("TWILIO_API_KEY")!;
  const res = await fetch(`${TWILIO_GATEWAY}/Messages.json`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "X-Connection-Api-Key": TWILIO_API_KEY,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({ To: TO_NUMBER, From: fromNumber, Body: body }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Twilio send failed [${res.status}]: ${JSON.stringify(data)}`);
  return data;
}

async function getFirstTwilioNumber(): Promise<string> {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
  const TWILIO_API_KEY = Deno.env.get("TWILIO_API_KEY")!;
  const res = await fetch(`${TWILIO_GATEWAY}/IncomingPhoneNumbers.json?PageSize=1`, {
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "X-Connection-Api-Key": TWILIO_API_KEY,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Twilio list numbers failed [${res.status}]: ${JSON.stringify(data)}`);
  const num = data?.incoming_phone_numbers?.[0]?.phone_number;
  if (!num) throw new Error("No Twilio phone numbers found on your account. Buy one in the Twilio console.");
  return num;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, alreadySent } = await req.json();
    if (alreadySent) {
      return new Response(JSON.stringify({ ready: false, skipped: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");
    if (!Deno.env.get("TWILIO_API_KEY")) throw new Error("TWILIO_API_KEY is not configured");

    const transcript = (messages || [])
      .map((m: any) => `${m.role === "user" ? "Visitor" : "Alyssa"}: ${m.content}`)
      .join("\n");

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: DETECTOR_PROMPT },
          { role: "user", content: transcript },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiRes.ok) {
      const t = await aiRes.text();
      console.error("Detector AI error:", aiRes.status, t);
      return new Response(JSON.stringify({ ready: false, error: "detector_failed" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiJson = await aiRes.json();
    const content = aiJson?.choices?.[0]?.message?.content || "{}";
    let parsed: any = {};
    try { parsed = JSON.parse(content); } catch { parsed = {}; }

    if (!parsed.ready) {
      return new Response(JSON.stringify({ ready: false }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fromNumber = await getFirstTwilioNumber();
    const smsBody = [
      "🌟 New Promptly lead (via Alyssa)",
      parsed.name ? `Name: ${parsed.name}` : null,
      parsed.contact ? `Contact: ${parsed.contact}` : null,
      `Wants: ${parsed.summary || "(no summary)"}`,
      parsed.details ? `Details: ${parsed.details}` : null,
    ].filter(Boolean).join("\n");

    await sendSms(smsBody, fromNumber);

    return new Response(JSON.stringify({ ready: true, sent: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("lead-summary-sms error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
